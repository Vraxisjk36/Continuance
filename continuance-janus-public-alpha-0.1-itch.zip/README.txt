CONTINUANCE: JANUS PROTOCOL — PUBLIC ALPHA 0.1
Build 3.1 / Itch Playtest

UPLOAD
- Upload the ZIP as an HTML game on itch.io.
- index.html is at the ZIP root.
- Recommended: Mobile Friendly ON.
- Recommended: launch in fullscreen / click-to-launch.

PLAYTEST NOTES
- Best experienced with headphones.
- Progress saves automatically in the browser on that device.
- Settings includes COPY PLAYTEST REPORT for bug reports.
- No remote telemetry is enabled in this build.
- No external scripts, fonts, CDNs, or network dependencies are used.

FEEDBACK TO ASK FOR
1. Where did you get stuck?
2. Which Trial was strongest/weakest?
3. Did any button/input become inaccessible on mobile?
4. Which puzzle felt unfair or confusing?
5. Did you trust the Architect?
6. Did you finish Trial XII? Did you discover anything after it?
7. Would you play another CONTINUANCE Protocol?
